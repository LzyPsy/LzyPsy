﻿namespace GourmetCoffee_Structure
{

    public class Product
    {

        private string code;
        private string description;
        private double price;

        public Product(string initialCode, string initialDescription, double initialPrice)
        {
            code = initialCode;
            description = initialDescription;
            price = initialPrice;
        }

        public string getCode()
        {
            return code;
        }

        public string getDescription()
        {
            return description;
        }

        public double getPrice()
        {
            return price;
        }

        public bool Equals(Product product)
        {
            return product.getCode().Equals(code);
        }

        public string toString()
        {
            return code + "_" + description + "_" + price;
        }

    }
}