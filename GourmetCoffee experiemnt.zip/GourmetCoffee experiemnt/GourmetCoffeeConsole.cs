﻿
namespace GourmetCoffee_Structure
{
    public class GourmetCoffeeConsole
    {

        private Catalog catalog;
        private Order currentOrder;
        private Sales sales;
        private SalesFormatter salesFormatter;

        /**
         * Loads data into the catalog and starts the application.
         *
         * @param args  String arguments.  Not used.
         * @throws IOException if there are errors in the input.
         */
        public static void Main(string[] args)
        {
            Catalog catalog = null;
            Sales sales = null;

            try
            {
                string filename = "";
                string filename2 = "";

                if (args.Length != 2)
                {
                    filename = "catalog.dat";
                    filename2 = "sales.dat";
                }
                else
                {
                    filename = args[0];
                    filename2 = args[1];
                }
                catalog =
                        new FileCatalogLoader().loadCatalog(filename);
                sales =
                        new FileSalesLoader().loadSales(filename2, catalog);
            }
            catch (FileNotFoundException fnfe)
            {
                Console.WriteLine("The file does not exist");

                Environment.Exit(1);

            }
            catch (Exception e)
            {
                Console.WriteLine("The file contains malformed data: "
                        + e.Message);

                Environment.Exit(1);
            }

            GourmetCoffeeConsole application =
                    new GourmetCoffeeConsole(catalog, sales);
            application.run();

        }

        /**
         * Constructs a <code>GourmetCoffee</code> object and
         * initializes the catalog and sales data.
         *
         * @param initialCatalog a product catalog
         */
        private GourmetCoffeeConsole(Catalog catalog, Sales sales)
        {
            this.catalog = catalog;
            this.sales = sales;
            currentOrder = new Order();
        }

        /*
         * Presents the user with a menu of options and executes the
         * selected task.
         */
        private void run()
        {

            int choice = getChoice1();

            while (choice != 0)
            {

                if (choice == 1)
                {
                    displayCatalog();
                }
                else if (choice == 2)
                {
                    displayProductInfo();
                }
                else if (choice == 3)
                {
                    displayOrder();
                }
                else if (choice == 4)
                {
                    addModifyProduct();
                }
                else if (choice == 5)
                {
                    removeProduct();
                }
                else if (choice == 6)
                {
                    saleOrder();
                }
                else if (choice == 7)
                {
                    displayOrdersSold();
                }
                else if (choice == 8)
                {
                    displayNumberOfOrders(readProduct());
                }
                else if (choice == 9)
                {
                    displayTotalQuantityOfProducts();
                }
                else if (choice == 10)
                {
                    displayText();
                }
                else if (choice == 11)
                {
                    SaveText();
                }

                choice = getChoice1();
            }
        }

        /*
         * Displays a menu of options and verifies the user's choice.
         *
         * @return an integer in the range [0,7]
         */

        private void displayText()
        {
            int choice = getChoice2();

            while (choice != 0)
            {
                if (choice == 0)
                {
                    return;
                }
                else if (choice == 1)
                {
                    setSalesFormatter(PlainTextSalesFormatter.getSingletonInstance());
                    displaySales();
                }
                else if (choice == 2)
                {
                    setSalesFormatter(HTMLSalesFormatter.getSingletonInstance());
                    displaySales();
                }
                else if (choice == 3)
                {
                    setSalesFormatter(XMLSalesFormatter.getSingletonInstance());
                    displaySales();
                }
                choice = getChoice2();
            }
        }

        private void SaveText()
        {
            int choice = getChoice3();

            while (choice != 0)
            {
                if (choice == 0)
                {
                    return;
                }
                else if (choice == 1)
                {
                    setSalesFormatter(PlainTextSalesFormatter.getSingletonInstance());
                    writeFile(
                            readFilename(),
                            salesFormatter.formatSales(sales));
                }
                else if (choice == 2)
                {
                    setSalesFormatter(HTMLSalesFormatter.getSingletonInstance());
                    writeFile(
                            readFilename(),
                            salesFormatter.formatSales(sales));
                }
                else if (choice == 3)
                {
                    setSalesFormatter(XMLSalesFormatter.getSingletonInstance());
                    writeFile(
                            readFilename(),
                            salesFormatter.formatSales(sales));
                }
                choice = getChoice3();
            }
        }

        private void writeFile(string filename, string content)
        {

            using (StreamWriter sw = new StreamWriter(filename + ".dat"))
            {
                sw.WriteLine(content);
            }

        }
        private string readFilename()
        {
            Console.WriteLine("Filename> ");
            return Console.ReadLine();
        }

        private void setSalesFormatter(SalesFormatter newFormatter)
        {
            salesFormatter = newFormatter;
        }

        private void displaySales()
        {
            Console.WriteLine(salesFormatter.formatSales(sales));
        }


        private int getChoice1()
        {

            int input;

            do
            {
                Console.WriteLine();
                Console.Write(
                    "[0] Quit\n"
                            + "[1] Display catalog\n"
                            + "[2] Display product\n"
                            + "[3] Display current order\n"
                            + "[4] Add|modify product to|in current order\n"
                            + "[5] Remove product from current order\n"
                            + "[6] Register sale of current order\n"
                            + "[7] Display sales\n"
                            + "[8] Display number of orders with a specific product\n"
                            + "[9] Display the total quantity sold for each product\n"
                            + "[10] Display SalesFormatter\n"
                            + "[11] Save SalesFormatter\n"
                            + "choice> ");
                try
                {
                    input = int.Parse(Console.ReadLine());
                    Console.WriteLine();

                    if (0 <= input && 11 >= input)
                    {
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Invalid choice:  " + input);
                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("Invalid choice");
                }
            } while (true);

            return input;
        }

        private int getChoice2()
        {

            int input;

            do
            {
                Console.WriteLine();
                Console.Write(
                    "[0] Quit\n"
                            + "[1] Display PlainTextSalesFormatter\n"
                            + "[2] Display HTMLSalesFormatter\n"
                            + "[3] Display XMLSalesFormatter\n"
                            + "choice> ");
                try
                {
                    input = int.Parse(Console.ReadLine());
                    Console.WriteLine();

                    if (0 <= input && 3 >= input)
                    {
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Invalid choice:  " + input);
                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("Invalid choice");
                }
            } while (true);

            return input;
        }

        private int getChoice3()
        {

            int input;

            do
            {
                Console.WriteLine();
                Console.Write(
                    "[0] Quit\n"
                            + "[1] Save PlainTextSalesFormatter\n"
                            + "[2] Save HTMLSalesFormatter\n"
                            + "[3] Save XMLSalesFormatter\n"
                            + "choice> ");
                try
                {
                    input = int.Parse(Console.ReadLine());
                    Console.WriteLine();

                    if (0 <= input && 3 >= input)
                    {
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Invalid choice:  " + input);
                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("Invalid choice");
                }
            } while (true);

            return input;
        }

        /**
         * Displays the catalog.
         */
        public void displayCatalog()
        {

            int size = catalog.getNumberOfProducts();

            if (size == 0)
            {
                Console.WriteLine("The catalog is empty");
            }
            else
            {
                foreach (Product product in catalog.getProducts())
                {
                    Console.WriteLine(product.getCode() + " " +
                            product.getDescription());
                }
            }
        }

        /**
         * Displays the information of a product
         */
        public void displayProductInfo()
        {

            Product product = readProduct();

            Console.WriteLine("  Description: " + product.getDescription());
            Console.WriteLine("  Price: " + product.getPrice());
            if (product is Coffee)
            {

                Coffee coffee = (Coffee)product;

                Console.WriteLine("  Origin: " + coffee.getOrigin());
                Console.WriteLine("  Roast: " + coffee.getRoast());
                Console.WriteLine("  Flavor: " + coffee.getFlavor());
                Console.WriteLine("  Aroma: " + coffee.getAroma());
                Console.WriteLine("  Acidity: " + coffee.getAcidity());
                Console.WriteLine("  Body: " + coffee.getBody());
            }
            else if (product is CoffeeBrewer)
            {

                CoffeeBrewer brewer = (CoffeeBrewer)product;

                Console.WriteLine("  Model: " + brewer.getModel());
                Console.WriteLine("  Water Supply: " + brewer.getWaterSupply());
                Console.WriteLine("  Number of Cups: " + brewer.getNumberOfCups());
            }
        }

        /**
         * Displays the current order.
         */
        public void displayOrder()
        {

            int size = currentOrder.getNumberOfItems();

            if (size == 0)
            {
                Console.WriteLine("The current order is empty");
            }
            else
            {
                foreach (OrderItem orderItem in currentOrder.getItems())
                {
                    Console.WriteLine(orderItem.toString());
                }
                Console.WriteLine("Total: " + currentOrder.getTotalCost());
            }
        }

        /**
         * Modifies the current order: if the specified product is not already
         * part of the order, it is added; otherwise, the quantity of the
         * specified product is updated.
         */
        public void addModifyProduct()
        {

            Product product = readProduct();
            int quantity = readQuantity();
            OrderItem orderItem = currentOrder.getItem(product);

            if (orderItem == null)
            {
                currentOrder.addItem(new OrderItem(product, quantity));
                Console.WriteLine("The product " + product.getCode()
                + " has been added");
            }
            else
            {
                orderItem.setQuantity(quantity);
                Console.WriteLine("The quantity of the product " +
                        product.getCode() + " has been modified");
            }
        }

        /**
         * Removes a product from the current order.
         */
        public void removeProduct()
        {

            Product product = readProduct();
            OrderItem orderItem = currentOrder.getItem(product);

            if (orderItem != null)
            {
                currentOrder.removeItem(orderItem);
                Console.WriteLine("The product " + product.getCode()
                + " has been removed from the current order");
            }
            else
            {
                Console.WriteLine(
                        "There are no products in the current order with that code");
            }
        }

        /**
         * Registers the sale of the current order.
         */
        public void saleOrder()
        {

            if (currentOrder.getNumberOfItems() > 0)
            {
                sales.addOrder(currentOrder);
                currentOrder = new Order();
                using (StreamWriter sw = new StreamWriter("sales.dat"))
                {
                    foreach (Order order in sales.getOrders())
                    {
                        sw.WriteLine("----------");
                        foreach (OrderItem orderitem in order.getItems())
                        {
                            sw.WriteLine(orderitem.getQuantity());
                            sw.WriteLine(orderitem.getProduct().getCode());
                        }
                    }
                }

                using (StreamWriter sw = new StreamWriter(
                    "D:\\成果\\GourmetCoffee Form\\bin\\Debug\\net6.0-windows\\sales.dat"))
                {
                    foreach (Order order in sales.getOrders())
                    {
                        sw.WriteLine("----------");
                        foreach (OrderItem orderitem in order.getItems())
                        {
                            sw.WriteLine(orderitem.getQuantity());
                            sw.WriteLine(orderitem.getProduct().getCode());
                        }
                    }
                }
                Console.WriteLine("The sale of the order has been registered");
            }
            else
            {
                Console.WriteLine("The current order is empty");
            }
        }

        /**
         * Displays the orders that have been sold.
         */
        public void displayOrdersSold()
        {

            int numOrders = sales.getNumberOfOrders();

            if (numOrders != 0)
            {
                int orderNumber = 1;
                foreach (Order order in sales.getOrders())
                {

                    Console.WriteLine("Order " + orderNumber++);

                    foreach (OrderItem orderItem in order.getItems())
                    {
                        Console.WriteLine("   " + orderItem.toString());
                    }
                    Console.WriteLine("   Total: " + order.getTotalCost());
                }
            }
            else
            {
                Console.WriteLine("There are no sales");
            }
        }


        /**
         * Displays the number of orders that contain a specified product
         *
         * @param product the <code>Product</code> object to be displayed.
         * @throws IOException 
         */
        public void displayNumberOfOrders(Product product)
        {

            int number = 0;
            foreach (Order order in sales.getOrders())
            {
                foreach (OrderItem orderItem in order.getItems())
                {
                    if (orderItem.getProduct().getCode().Equals(product.getCode()))
                    {
                        number++;
                        break;
                    }
                }
            }
            Console.WriteLine("Number of orders that contains the product "
                        + product.getCode() + ": " + number);

        }

        /**
         * Displays the total quantity of product that have has sold for each
         * product in the catalog.
         */
        public void displayTotalQuantityOfProducts()
        {

            int numberOfproduct = catalog.getNumberOfProducts();
            int[] number = new int[numberOfproduct];
            foreach (Order order in sales.getOrders())
            {
                foreach (OrderItem orderItem in order.getItems())
                {
                    foreach (Product pro in catalog.getProducts())
                    {
                        if (orderItem.getProduct().Equals(pro))
                        {
                            number[catalog.getProducts().IndexOf(pro)] += orderItem.getQuantity();
                            break;
                        }
                    }
                }
            }
            int i = 0;
            foreach (Product pro in catalog.getProducts())
            {
                Console.WriteLine(pro.getCode() + " " + number[i]);
                i++;
            }

        }

        /*
         * Prompts user for a product code and locates the associated
         * <code>Product</code> object.
         *
         * @return reference to the <code>Product</code> object with
         *         the specified code
         */
        private Product readProduct()
        {

            do
            {
                Console.Write("Product code> ");

                Product product = catalog.getProduct(Console.ReadLine());

                if (product != null)
                {

                    return product;

                }
                else
                {
                    Console.WriteLine("There are no products with that code");
                }
            } while (true);
        }

        /*
         * Prompts user for the product quantity and verifies the
         * user's response.
         *
         * @return a positive integer
         */
        private int readQuantity()
        {

            int quantity;

            do
            {

                Console.Write("Quantity> ");
                quantity = int.Parse(Console.ReadLine());
                if (quantity > 0)
                {

                    return quantity;

                }
                else
                {
                    Console.WriteLine(
                            "Invalid input. Please enter a positive integer");
                }
            } while (true);
        }
    }
}