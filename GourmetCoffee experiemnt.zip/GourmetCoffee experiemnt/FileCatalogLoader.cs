﻿namespace GourmetCoffee_Structure
{

    public class FileCatalogLoader : CatalogLoader
    {

        public Catalog loadCatalog(string filename)
        {
            Catalog catalog = new Catalog();

            try
            {
                if (File.Exists(filename))
                {
                    using (StreamReader sr = new StreamReader(filename))
                    {
                        string line;
                        while ((line = sr.ReadLine()) != null)
                        {
                            if (line.StartsWith("Product"))
                                catalog.addProduct(readProduct(line));
                            else if (line.StartsWith("Coffee"))
                                catalog.addProduct(readCoffee(line));
                            else if (line.StartsWith("Brewer"))
                                catalog.addProduct(readCoffeeBrewer(line));
                        }
                    }
                }
                else
                    File.Create(filename);
            }

            catch (Exception e)
            {
                throw e;
            }

            return catalog;
        }

        private Product readProduct(string line)
        {
            string[] str = line.Split("_");

            if (str.Length != 4)
            {
                throw new DataFormatException(line);
            }
            else
            {
                try
                {
                    return new Product(str[1], str[2], double.Parse(str[3]));
                }
                catch (DataFormatException num)
                {
                    throw new DataFormatException(line);
                }
            }
        }

        private Coffee readCoffee(string line)
        {

            string[] str = line.Split("_");
            if (str.Length != 10)
            {
                throw new DataFormatException(line);
            }
            else
            {
                try
                {
                    return new Coffee(str[1], str[2], double.Parse(str[3])
                            , str[4], str[5], str[6], str[7], str[8], str[9]);
                }
                catch (DataFormatException num)
                {
                    throw new DataFormatException(line);
                }
            }
        }

        private CoffeeBrewer readCoffeeBrewer(string line)
        {

            string[] str = line.Split("_");

            if (str.Length != 7)
            {
                throw new DataFormatException(line);
            }
            else
            {
                try
                {

                    return new CoffeeBrewer(str[1], str[2], double.Parse(str[3])
                            , str[4], str[5], int.Parse(str[6]));
                }
                catch (DataFormatException num)
                {
                    throw new DataFormatException(line);
                }
            }
        }

    }
}
