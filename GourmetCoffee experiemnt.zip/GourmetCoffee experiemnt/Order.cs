﻿using System.Collections;

namespace GourmetCoffee_Structure
{

    public class Order
    {

        ArrayList items;

        public Order()
        {
            items = new ArrayList();
        }

        public ArrayList getItems()
        {
            return items;
        }

        public void addItem(OrderItem orderItem)
        {
            items.Add(orderItem);
        }

        public void removeItem(OrderItem orderItem)
        {
            items.Remove(orderItem);
        }

        public OrderItem getItem(Product product)
        {
            foreach (OrderItem element in items)
            {
                if (element.getProduct().getCode().Equals(product.getCode()))
                    return element;
            }
            return null;
        }

        public int getNumberOfItems()
        {
            return items.Count;
        }

        public string getTotalCost()
        {
            double result = 0;
            foreach (OrderItem element in items)
            {
                result += element.getValue();
            }
            return result.ToString("C");
        }

    }
}