﻿namespace GourmetCoffee_Structure
{
    public class Coffee : Product
    {

        private string origin;
        private string roast;
        private string flavor;
        private string aroma;
        private string acidity;
        private string body;

        public Coffee(string initialCode, string initialDescription, double initialPrice, string origin, string roast,
                string flavor, string aroma, string acidity, string body) : base(initialCode, initialDescription, initialPrice)
        {
            this.origin = origin;
            this.roast = roast;
            this.flavor = flavor;
            this.aroma = aroma;
            this.acidity = acidity;
            this.body = body;
        }

        public string getOrigin()
        {
            return origin;
        }

        public string getRoast()
        {
            return roast;
        }

        public string getFlavor()
        {
            return flavor;
        }

        public string getAroma()
        {
            return aroma;
        }

        public string getAcidity()
        {
            return acidity;
        }

        public string getBody()
        {
            return body;
        }

        public new string toString()
        {
            return getCode() + "_" + getDescription() + "_" + getPrice()
                    + "_" + origin + "_" + roast
                    + "_" + flavor + "_" + aroma
                    + "_" + acidity + "_" + body;
        }

    }
}