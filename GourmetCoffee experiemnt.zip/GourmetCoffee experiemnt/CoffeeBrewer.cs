﻿namespace GourmetCoffee_Structure
{

    public class CoffeeBrewer : Product
    {

        private string model;
        private string waterSupply;
        private int numberOfCups;

        public CoffeeBrewer(string initialCode, string initialDescription, double initialPrice, string model,
                string waterSupply, int numberOfCups) : base(initialCode, initialDescription, initialPrice)
        {
            this.model = model;
            this.waterSupply = waterSupply;
            this.numberOfCups = numberOfCups;
        }

        public string getModel()
        {
            return model;
        }

        public string getWaterSupply()
        {
            return waterSupply;
        }

        public int getNumberOfCups()
        {
            return numberOfCups;
        }

        public new string toString()
        {
            return getCode() + "_" + getDescription() + "_" + getPrice()
            + "_" + getModel() + "_" + getWaterSupply() + "_" + getNumberOfCups();
        }

    }
}