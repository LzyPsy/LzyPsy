﻿namespace GourmetCoffee_Structure
{

    public class OrderItem
    {

        private Product product;
        private int quantity;

        public OrderItem(Product product, int initialQuantity)
        {
            this.product = product;
            quantity = initialQuantity;
        }

        public Product getProduct()
        {
            return product;
        }

        public int getQuantity()
        {
            return quantity;
        }

        public void setQuantity(int newquantity)
        {
            quantity = newquantity;
        }

        public double getValue()
        {
            return (double)product.getPrice() * quantity;
        }

        public string toString()
        {
            return quantity + " " + product.getCode() + " " + product.getPrice();
        }

    }
}