﻿namespace GourmetCoffee_Structure
{

    public interface CatalogLoader
    {

        Catalog loadCatalog(string fileName);

    }
}