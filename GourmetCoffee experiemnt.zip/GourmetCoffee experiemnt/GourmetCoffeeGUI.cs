﻿
namespace GourmetCoffee_Structure
{
    public static class GourmetCoffeeGUI
    {

        static Catalog catalog;
        static Sales sales;

        static GourmetCoffeeGUI()
        {
            string filename = "catalog.dat";
            string filename2 = "sales.dat";

            catalog =
                    new FileCatalogLoader().loadCatalog(filename);
            sales =
                    new FileSalesLoader().loadSales(filename2, catalog);
        }
        public static Catalog getCatalog()
        {
            return catalog;
        }
        public static Sales getSales()
        {
            return sales;
        }
    }
}
