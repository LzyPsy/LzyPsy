﻿namespace GourmetCoffee_Structure
{

    public interface SalesLoader
    {

        Sales loadSales(string fileName, Catalog catalog);

    }
}