﻿namespace GourmetCoffee_Structure
{

    public interface SalesFormatter
    {

        public string formatSales(Sales sales);

    }
}
