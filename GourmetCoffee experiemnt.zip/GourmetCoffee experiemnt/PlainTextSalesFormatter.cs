﻿namespace GourmetCoffee_Structure
{

    public class PlainTextSalesFormatter : SalesFormatter
    {

        private static PlainTextSalesFormatter singletonInstance = new PlainTextSalesFormatter();

        static public PlainTextSalesFormatter getSingletonInstance()
        {
            return singletonInstance;
        }

        private PlainTextSalesFormatter()
        {

        }

        public string formatSales(Sales sales)
        {
            string result = new string("");
            int orderNumber = 1;
            foreach (Order order in sales.getOrders())
            {

                result += "------------------------\r\n"
                        + "Order " + orderNumber++ + "\r\n"
                        + "\r\n";
                foreach (OrderItem orderItem in order.getItems())
                {
                    result += " " + orderItem.toString() + "\r\n";
                }
                result += "\r\n" + "Total = " + order.getTotalCost() + "\r\n";
            }

            return result;
        }

    }
}
