﻿namespace GourmetCoffee_Structure
{

    public class XMLSalesFormatter : SalesFormatter
    {

        private static XMLSalesFormatter singletonInstance = new XMLSalesFormatter();

        static public XMLSalesFormatter getSingletonInstance()
        {
            return singletonInstance;
        }

        private XMLSalesFormatter()
        {

        }

        public string formatSales(Sales sales)
        {
            string result = new string("");

            result += "<Sales>\r\n";
            foreach (Order order in sales.getOrders())
            {
                result += "  <Order total=\"" + order.getTotalCost() + "\">\r\n";
                foreach (OrderItem orderItem in order.getItems())
                {
                    result += "    <OrderItem quantity=\"" + orderItem.getQuantity() + "\" price=\"" + orderItem.getProduct().getPrice() + "\">" + orderItem.getProduct().getCode() + "</OrderItem>\r\n";
                }
                result += "  </Order>\r\n";
            }
            result += "</Sales>";

            return result;
        }

    }
}
