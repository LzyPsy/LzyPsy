﻿using System.Collections;

namespace GourmetCoffee_Structure
{

    public class Sales
    {

        ArrayList orders;

        public Sales()
        {
            orders = new ArrayList();
        }

        public ArrayList getOrders()
        {
            return orders;
        }

        public void addOrder(Order order)
        {
            orders.Add(order);
        }

        public int getNumberOfOrders()
        {
            return orders.Count;
        }

    }
}
