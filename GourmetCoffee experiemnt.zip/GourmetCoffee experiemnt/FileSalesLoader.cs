﻿namespace GourmetCoffee_Structure
{

    public class FileSalesLoader : SalesLoader
    {

        public Sales loadSales(string filename, Catalog catalog)
        {
            Sales sales = new Sales();
            try
            {
                if (File.Exists(filename))
                {
                    using (StreamReader sr = new StreamReader(filename))
                    {
                        string line = sr.ReadLine();
                        while (true)
                        {
                            if (line == null)
                                break;
                            Order order = new Order();
                            while (true)
                            {
                                line = sr.ReadLine();
                                if (line == null || line.Equals("----------"))
                                    break;
                                int quantity = int.Parse(line);
                                line = sr.ReadLine();
                                Product product = catalog.getProduct(line);
                                OrderItem orderitem = new OrderItem(product, quantity);
                                order.addItem(orderitem);
                            }
                            sales.addOrder(order);
                        }
                    }
                }
                else
                    File.Create(filename);
            }
            catch (Exception e)
            {
                throw e;
            }

            return sales;
        }

    }
}