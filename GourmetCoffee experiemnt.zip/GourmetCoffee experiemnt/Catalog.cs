﻿using System.Collections;

namespace GourmetCoffee_Structure
{

    public class Catalog
    {

        ArrayList products;

        public Catalog()
        {
            products = new ArrayList();
        }

        public ArrayList getProducts()
        {
            return products;
        }

        public void addProduct(Product product)
        {
            products.Add(product);
        }

        public Product getProduct(string code)
        {
            foreach (Product element in products)
            {
                if (element.getCode().Equals(code))
                    return element;
            }
            return null;
        }

        public int getNumberOfProducts()
        {
            return products.Count;
        }

    }
}