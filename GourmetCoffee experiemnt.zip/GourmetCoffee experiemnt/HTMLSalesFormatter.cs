﻿namespace GourmetCoffee_Structure
{

    public class HTMLSalesFormatter : SalesFormatter
    {

        private static HTMLSalesFormatter singletonInstance = new HTMLSalesFormatter();

        static public HTMLSalesFormatter getSingletonInstance()
        {
            return singletonInstance;
        }

        private HTMLSalesFormatter()
        {

        }

        public string formatSales(Sales sales)
        {
            string result = new string("");

            result += "<html>\r\n"
                    + "  <body>\r\n"
                    + "    <center><h2>Orders</h2></center>";
            foreach (Order order in sales.getOrders())
            {
                result += "<hr>\r\n"
                        + "    <h4>Total = " + order.getTotalCost() + "</h4>\r\n";
                foreach (OrderItem orderItem in order.getItems())
                {
                    result += "      <p>\r\n"
                            + "        <b>code:</b> " + orderItem.getProduct().getCode() + "<br>\r\n"
                            + "        <b>quantity:</b> " + orderItem.getQuantity() + "<br>\r\n"
                            + "        <b>price:</b> " + orderItem.getProduct().getPrice() + "\r\n"
                            + "     </p>\r\n";
                }
            }
            result += "  </body>\r\n"
                    + "</html>";

            return result;
        }

    }
}